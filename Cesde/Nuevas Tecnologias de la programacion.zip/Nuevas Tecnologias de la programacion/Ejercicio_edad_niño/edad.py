edad = int(input("infrese la edad del niño "))
altura = int(input("infrese la altura del niño "))

if edad >= 11 and altura <= 120:
    print("puede pasar")

print("no puede pasar")    